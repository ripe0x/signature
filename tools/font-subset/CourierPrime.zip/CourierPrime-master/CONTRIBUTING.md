# Contributing to Courier Prime

1. Fork this repo
2. Create a new branch for your proposed changes
3. Make changes in your branch
4. Commit changes to your branch
5. Push to your remote
6. Create a new pull request
